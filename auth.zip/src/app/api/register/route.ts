import { NextResponse } from "next/server";
import { pool } from "@/actions/conection-db";
import bcrypt from "bcrypt";
import { signUpSchema } from "@/lib/zod";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    // Validar datos con Zod
    const { name, email, username, password } = signUpSchema.parse(body);

    // Hashear la contraseña
    const hashedPassword = await bcrypt.hash(password, 10);

    // Guardar usuario en la BD
    const query = `
      INSERT INTO users (name, email, username, password_hash)
      VALUES ($1, $2, $3, $4)
      RETURNING id, name, email, username;
    `;
    const values = [name, email, username, hashedPassword];

    const result = await pool.query(query, values);
    return NextResponse.json({ user: result.rows[0] }, { status: 201 });

  } catch (error) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Error registering user" }, { status: 400 });
  }
}