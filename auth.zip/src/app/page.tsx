import PageHeaders from "@/components/page-headers"
import PageBody from "@/components/page-body"
import PageTeam from "@/components/page-team"

export default function Home() {
  return (
    <div>
      <PageHeaders />
      <PageBody />
      <PageTeam />
    </div>
  )
}
