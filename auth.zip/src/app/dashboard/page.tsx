"use client"; // Indica que este componente debe ejecutarse en el cliente

import { SignOut } from "@/components/logout-button";
import { useSession } from "next-auth/react";

export default function DashboardPage() {
  const { data: session, status } = useSession(); // useSession se usa dentro del componente

  if (status === "loading") {
    return <p>Cargando sesión...</p>;
  }

  if (!session) {
    return <p>No estás autenticado.</p>;
  }

  return (
    <div className="container">
      <pre>{JSON.stringify(session, null, 2)}</pre>
      <SignOut />
    </div>
  );
}