import NextAuth from "next-auth";
import PostgresAdapter from "@auth/pg-adapter";
import { pool } from "./actions/conection-db";
import type { AdapterUser } from "next-auth/adapters";
import Credentials from "next-auth/providers/credentials";
import { signInSchema } from "@/lib/zod";
import { verifyUserCredentials } from "@/actions/email";

export type ExtendedUser = AdapterUser & {
  expires_at: string;
  session_expires: string;
};

export const { handlers, auth, signIn, signOut } = NextAuth({
  adapter: PostgresAdapter(pool),
  providers: [
    Credentials({
      credentials: {
        email: {},
        password: {},
      },
      authorize: async (credentials) => {
        if (!credentials) return null;
        try {
          const { email, password } = await signInSchema.parseAsync(credentials);
          const user = await verifyUserCredentials(email, password);
          if (!user) return null;
          
          // Establecer expiración de sesión (30 minutos)
          const sessionExpires = new Date();
          sessionExpires.setMinutes(sessionExpires.getMinutes() + 30);
  
          // Establecer expiración de reautenticación (7 días)
          const authExpires = new Date();
          authExpires.setDate(authExpires.getDate() + 7);
  
          return { 
            id: user.id, 
            email: user.email,
            expires_at: authExpires.toISOString(),  // Guardamos como string ISO
            session_expires: sessionExpires.toISOString()
          } as ExtendedUser;
        } catch (error) {
          console.error("Authorization error:", error);
          return null;
        }
      },
    }),
  ],
  session: { strategy: "jwt" },
  callbacks: {
    async session({ session, token }) {
      const now = new Date();
    
      const sessionExpires = token.session_expires
        ? new Date(String(token.session_expires))
        : null;
      const authExpires = token.expires_at
        ? new Date(String(token.expires_at))
        : null;
    
      if ((sessionExpires && sessionExpires < now) || (authExpires && authExpires < now)) {
        return { ...session, error: "SessionExpired" };
      }
    
      // Renueva `session_expires` si aún no ha caducado completamente
      if (sessionExpires && sessionExpires > now) {
        const newSessionExpires = new Date();
        newSessionExpires.setMinutes(newSessionExpires.getMinutes() + 30);
        token.session_expires = newSessionExpires.toISOString();
      }
    
      session.user = token.user as unknown as AdapterUser;
      session.expires = token.session_expires
        ? new Date(String(token.session_expires)).toISOString() as unknown as (Date & string)
        : session.expires;
      return session;
    },    
    async jwt({ token, user }) {
      if (user) {
        // Aseguramos que user sea ExtendedUser
        token.user = user as ExtendedUser;
        token.expires_at = (user as ExtendedUser).expires_at;
        token.session_expires = (user as ExtendedUser).session_expires;
      }
      return token;
    }, 
  },
  pages: {
    signIn: "/auth/login",
    error: "/auth/login",
    signOut: "/auth/login",
  },
  cookies: {
    sessionToken: {
      name: `next-auth.session-token`,
      options: {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax", // o "strict" según tu caso
        path: "/",
      },
    },
  },
});
