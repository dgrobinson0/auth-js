"use client"; // Indica que este componente debe ejecutarse en el cliente

import { useSession } from "next-auth/react";

export default function SessionVerification() {
  const { data: session, status } = useSession(); // useSession se usa dentro del componente

  if (status === "loading") {
    return <p>Cargando sesión...</p>;
  }

  if (!session) {
    return <p>No estás autenticado.</p>;
  }
}
pages: {
    signIn: "/auth/login",
    error: "/auth/login",
    signOut: "/auth/login",
  },
  
  callbacks: {
    async session({ session, token }) {
      const now = new Date();

      const sessionExpires = token.session_expires
        ? new Date(String(token.session_expires))
        : null;
      const authExpires = token.expires_at
        ? new Date(String(token.expires_at))
        : null;

      if ((sessionExpires && sessionExpires < now) || (authExpires && authExpires < now)) {
        return { ...session, error: "SessionExpired" };
      }

      // Renueva `session_expires` si aún no ha caducado completamente
      if (sessionExpires && sessionExpires > now) {
        const newSessionExpires = new Date();
        newSessionExpires.setMinutes(newSessionExpires.getMinutes() + 30);
        token.session_expires = newSessionExpires.toISOString();
      }

      session.user = token.user as unknown as AdapterUser;
      session.expires = token.session_expires
        ? new Date(String(token.session_expires)).toISOString() as unknown as (Date & string)
        : session.expires;
      return session;
    },    
    async jwt({ token, user }) {
      if (user) {
        // Aseguramos que user sea ExtendedUser
        token.user = user as ExtendedUser;
        token.expires_at = (user as ExtendedUser).expires_at;
        token.session_expires = (user as ExtendedUser).session_expires;
      }
      return token;
    },