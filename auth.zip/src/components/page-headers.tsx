'use client'

import { Button } from "@/components/ui/button"
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function PageHeaders() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function onClick() {
      setLoading(true);
      await new Promise((resolve) => setTimeout(resolve, 500)); //retardo para q se vea el cargando
      try {
        router.push("/auth/login");
      } catch (error) {
        console.log("Ocurrió un error inesperado");
      } finally {
        setLoading(false);
      }
    }
  return (
    <header className="bg-white" >
      <nav
        aria-label="Global"
        className="mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8 shadow-xl"
      >
        {/* Logo */}
        <div>
          <a href="#" className="-m-1.5 p-1.5">
            <span className="sr-only">UM-3764</span>
            <img
              alt="Logo"
              src="https://tailwindcss.com/plus-assets/img/logos/mark.svg?color=indigo&shade=600"
              className="h-8 w-auto"
            />
          </a>
        </div>

        {/* Botón de Login */}
        <div>
          <Button onClick={onClick} disabled={loading}>
            {loading ? "Cargando..." : "Iniciar Sesión"}
          </Button>
        </div>
      </nav>
    </header>
  )
}