import { pool } from "./conection-db";
import bcrypt from "bcryptjs";

// Interface para el usuario sin incluir la contraseña
interface User {
  id: string;
  email: string;
  created_at: Date;
}

// Función para obtener usuario por email
export async function getUserByEmail(email: string) {
  try {
    const normalizedEmail = email.toLowerCase();
    const result = await pool.query<{ id: string; email: string; password_hash: string; created_at: Date }>(
      "SELECT id, email, password_hash, created_at FROM users WHERE email = $1 LIMIT 1",
      [normalizedEmail]
    );

    return result.rows[0] || null;
  } catch (error) {
    console.error("Error fetching user:", error);
    return null;
  }
}

// Función para verificar credenciales del usuario
export async function verifyUserCredentials(email: string, password: string): Promise<User | null> {
  try {
    const user = await getUserByEmail(email);
    if (!user) return null;

    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) return null;

    // Retornar solo los datos necesarios
    return { id: user.id, email: user.email, created_at: user.created_at };
  } catch (error) {
    console.error("Error verifying credentials:", error);
    return null;
  }
}
