import bcrypt from 'bcrypt';

// Función para generar y hashear la contraseña
export async function saltAndHashPassword(password: string): Promise<string> {
  try {
    // Generar salt (recommended rounds: 10-12)
    const salt = await bcrypt.genSalt(12);
    
    // Hashear la contraseña con el salt
    const hashedPassword = await bcrypt.hash(password, salt);
    
    return hashedPassword;
  } catch (error) {
    console.error("Error hashing password:", error);
    throw new Error("Password hashing failed");
  }
}

// Función para verificar contraseñas (útil para el login)
export async function verifyPassword(
  candidatePassword: string,
  hashedPassword: string
): Promise<boolean> {
  return await bcrypt.compare(candidatePassword, hashedPassword);
}