import { NextResponse } from "next/server";
import { auth as nextAuth } from "./auth"; // Importar desde auth.ts

const publicRoutes = ["/"];
const authRoutes = ["/auth/login"];

export default nextAuth((req) => {
  const { nextUrl } = req;
  const isLoggedIn = !!req.auth;

  console.log({ isLoggedIn, path: nextUrl.pathname });

  if (publicRoutes.includes(nextUrl.pathname)) {
    return NextResponse.next();
  }

  if (isLoggedIn && authRoutes.includes(nextUrl.pathname)) {
    return NextResponse.redirect(new URL("/dashboard", nextUrl));
  }

  if (!isLoggedIn && !authRoutes.includes(nextUrl.pathname) && !publicRoutes.includes(nextUrl.pathname)) {
    return NextResponse.redirect(new URL("/auth/login", nextUrl));
  }

  return NextResponse.next();
});

export const config = {
  runtime: "nodejs",
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
};